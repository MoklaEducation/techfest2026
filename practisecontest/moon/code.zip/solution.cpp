#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int T; cin >> T;
    string s; getline(cin, s);
    for (int tc = 0; tc < T; tc++) {
        getline(cin, s);
        string a;
        for (char ch : s) if (ch != ' ') a.push_back((char)tolower((unsigned char)ch));
        bool ok = true;
        for (int i = 0, j = (int)a.size() - 1; i < j; i++, j--) if (a[i] != a[j]) ok = false;
        cout << (ok ? "TRUE" : "FALSE");
        if (tc + 1 < T) cout << '\n';
    }
    return 0;
}
