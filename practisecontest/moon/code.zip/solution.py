import sys

def solve_case(s):
    cleaned = ''.join(ch.lower() for ch in s if ch != ' ')
    return 'TRUE' if cleaned == cleaned[::-1] else 'FALSE'

def main():
    data = sys.stdin.read().splitlines()
    if not data: return
    t = int(data[0])
    ans = [solve_case(data[i]) for i in range(1, t+1)]
    print('\n'.join(ans))
if __name__ == '__main__': main()
