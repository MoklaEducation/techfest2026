import java.io.*;

public class Solution {
    static String solve(String s) {
        StringBuilder cleaned = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            if (ch != ' ') cleaned.append(Character.toLowerCase(ch));
        }
        int l = 0, r = cleaned.length() - 1;
        while (l < r) {
            if (cleaned.charAt(l) != cleaned.charAt(r)) return "FALSE";
            l++; r--;
        }
        return "TRUE";
    }
    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String first = br.readLine();
        int t = Integer.parseInt(first.trim());
        StringBuilder out = new StringBuilder();
        for (int i = 0; i < t; i++) {
            String line = br.readLine();
            if (line == null) line = "";
            if (i > 0) out.append('\n');
            out.append(solve(line));
        }
        System.out.print(out.toString());
    }
}
