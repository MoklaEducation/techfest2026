#include <bits/stdc++.h>
using namespace std;
int main(){
    ios::sync_with_stdio(false); cin.tie(nullptr);
    int T; cin >> T;
    for(int tc=0; tc<T; tc++){
        string s; cin >> s; int x=0,y=0;
        for(char c:s){ if(c=='N') y++; else if(c=='S') y--; else if(c=='E') x++; else if(c=='W') x--; }
        cout << "Position = (" << x << ", " << y << "), Distance = " << abs(x)+abs(y);
        if(tc+1<T) cout << '\n';
    }
    return 0;
}
