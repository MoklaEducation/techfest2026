import java.io.*;
public class Solution {
    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        int t = Integer.parseInt(br.readLine().trim()); StringBuilder out = new StringBuilder();
        for(int tc=0; tc<t; tc++){
            String s = br.readLine().trim(); int x = 0, y = 0;
            for(int i=0;i<s.length();i++){
                char c=s.charAt(i); if(c=='N') y++; else if(c=='S') y--; else if(c=='E') x++; else if(c=='W') x--;
            }
            if(tc>0) out.append('\n');
            out.append("Position = (").append(x).append(", ").append(y).append("), Distance = ").append(Math.abs(x)+Math.abs(y));
        }
        System.out.print(out.toString());
    }
}
