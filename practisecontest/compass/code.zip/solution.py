import sys

def main():
    lines = sys.stdin.read().splitlines()
    if not lines: return
    t = int(lines[0]); ans = []
    for i in range(1, t+1):
        x = y = 0
        for ch in lines[i].strip():
            if ch == 'N': y += 1
            elif ch == 'S': y -= 1
            elif ch == 'E': x += 1
            elif ch == 'W': x -= 1
        ans.append(f"Position = ({x}, {y}), Distance = {abs(x)+abs(y)}")
    print('\n'.join(ans))
if __name__ == '__main__': main()
